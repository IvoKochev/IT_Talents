
public class Task1 {

	public static void main(String[] args) {
		for(int i = -100; i< 101; i++){
			System.out.println(i);
		}
		for(int i = 100; i > -101; i--){
			System.out.println(i);
		}

	}

}
