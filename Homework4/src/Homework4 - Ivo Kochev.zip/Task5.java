
public class Task5 {

	public static void main(String[] args) {
		int[] array = new int[10];
		for(int i = 0; i < 10; i ++){
			array[i] = i*3;
			System.out.println("The " + (i+1) + " element is: " + array[i]);
		}
		

	}

}
