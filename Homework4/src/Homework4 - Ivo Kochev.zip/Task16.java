
public class Task16 {

	public static void main(String[] args) {
		

	}

}
