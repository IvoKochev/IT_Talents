import java.util.Scanner;

public class Task15 {

	public static void main(String[] args) {
		int hour;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter hour format 24: ");
		hour = sc.nextInt();
		if(hour >= 1 && hour <= 24){
			if(hour >= 4 && hour <=9){
				System.out.println("Good morning !");
			}
			if(hour > 9 && hour <= 18){
				System.out.println("Good afternoon !");
			} 
			if (hour > 18 || hour < 4){
				System.out.println("Good evening ! ");
			}
		}
		sc.close();
	}

}
