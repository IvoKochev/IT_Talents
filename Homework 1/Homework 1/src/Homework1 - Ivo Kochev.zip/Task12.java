import java.util.Scanner;

public class Task12 {

	public static void main(String[] args) {
		int day, month, year;
		boolean lean = false;
		Scanner sc = new Scanner(System.in);
		System.out.println("Day: ");
		day = sc.nextInt();
		System.out.println("Month: ");
		month = sc.nextInt();
		System.out.println("Year: ");
		year = sc.nextInt();
		if((year % 4 ==0 && year % 100 != 0) || year % 400 == 0){
			lean = true;
		}
		if(((month == 1 || month == 3 || month == 5 || month == 7|| month == 8 || month == 10) && day == 31) || ((month == 4 || month == 6 || month == 9 || month == 11) && day == 30) ||(month ==2 && day ==28 && !lean) || (month == 2 && day == 29 && lean)){
					month++;
					day = 1;
				}  else if(month == 12 && day == 31){
					day = 1;
					month = 1;
					year++;
				} else{
					day++;
				}
		System.out.println("The next date is: " + day + "." + month + "." + year);
		
	}

}
